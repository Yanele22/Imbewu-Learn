import "dotenv/config";
import cors from "cors";
import express from "express";
import { randomUUID } from "node:crypto";

const app = express();
const PORT = Number(process.env.PORT || 3001);
const MOMO_BASE_URL = process.env.MOMO_BASE_URL || "https://proxy.momoapi.mtn.com";
const MOMO_TARGET_ENVIRONMENT = process.env.MOMO_TARGET_ENVIRONMENT || "mtnsouthafrica";

app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true }));
app.use(express.json());

const products = [
  { id: "earphones", name: "Wireless Earphones", seller: "TechHaven", price: 499, category: "Electronics", emoji: "🎧" },
  { id: "running-shoes", name: "Running Shoes", seller: "Kasi Kicks", price: 450, category: "Fashion", emoji: "👟" },
  { id: "sourdough", name: "Sourdough Loaf", seller: "The Daily Crumb", price: 65, category: "Food", emoji: "🍞" },
  { id: "candle", name: "Scented Candle", seller: "Hearth & Home", price: 220, category: "Home", emoji: "🕯️" },
  { id: "studio-buds", name: "Studio Buds", seller: "Sound Studio", price: 459, category: "Electronics", emoji: "🎧" }
];
const payments = new Map();
const orders = new Map();

function configured() {
  return ["MOMO_SUBSCRIPTION_KEY", "MOMO_API_USER", "MOMO_API_KEY"].every((key) => Boolean(process.env[key]) && !process.env[key].startsWith("replace_"));
}

function normaliseMsisdn(value) {
  const phone = String(value || "").replace(/\D/g, "");
  if (!/^27\d{9}$/.test(phone)) throw new Error("payerMsisdn must be a South African number in 27XXXXXXXXX format, without +.");
  return phone;
}

async function momoAccessToken() {
  if (!configured()) throw new Error("MoMo is not configured. Add valid MoMo credentials to .env.");
  const basic = Buffer.from(`${process.env.MOMO_API_USER}:${process.env.MOMO_API_KEY}`).toString("base64");
  const response = await fetch(`${MOMO_BASE_URL}/collection/token/`, {
    method: "POST",
    headers: {
      "Ocp-Apim-Subscription-Key": process.env.MOMO_SUBSCRIPTION_KEY,
      "X-Target-Environment": MOMO_TARGET_ENVIRONMENT,
      Authorization: `Basic ${basic}`
    }
  });
  if (!response.ok) throw new Error(`MoMo token request failed (${response.status}).`);
  const body = await response.json();
  return body.access_token;
}

function momoHeaders(token, referenceId) {
  return {
    "Ocp-Apim-Subscription-Key": process.env.MOMO_SUBSCRIPTION_KEY,
    "X-Target-Environment": MOMO_TARGET_ENVIRONMENT,
    Authorization: `Bearer ${token}`,
    ...(referenceId ? { "X-Reference-Id": referenceId } : {})
  };
}

app.get("/health", (_req, res) => res.json({ status: "ok", momoConfigured: configured() }));

app.post("/api/auth/login", (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: "Mobile number is required." });
  // Demo login only. Replace with verified identity + hashed passwords before production.
  res.json({ token: `demo_${randomUUID()}`, user: { id: "demo-user", phone, name: "Nandi" } });
});

app.get("/api/products", (req, res) => {
  const query = String(req.query.q || "").toLowerCase();
  const matches = query ? products.filter((product) => Object.values(product).join(" ").toLowerCase().includes(query)) : products;
  res.json({ products: matches });
});

app.post("/api/ai/product-description", (req, res) => {
  const { name, price } = req.body;
  if (!name || !price) return res.status(400).json({ error: "Product name and price are required." });
  res.json({ description: `Experience dependable quality with ${name}. At R${price}, it is a smart local find for work, travel and everyday life.` });
});

app.get("/api/merchant/dashboard", (_req, res) => res.json({
  todaySales: 2450, orders: 12, products: 24,
  insight: "Your wireless earphones are your fastest-growing product. Consider restocking within the next 3 days."
}));

app.post("/api/payments/momo", async (req, res, next) => {
  try {
    const { amount, currency = "ZAR", payerMsisdn, externalId, payerMessage = "MoMo Market payment", payeeNote = "MoMo Market order", items = [] } = req.body;
    const cents = Number(amount);
    if (!Number.isFinite(cents) || cents <= 0) return res.status(400).json({ error: "amount must be greater than zero." });
    if (currency !== "ZAR") return res.status(400).json({ error: "Only ZAR is supported for this collection setup." });
    const referenceId = randomUUID();
    const token = await momoAccessToken();
    const response = await fetch(`${MOMO_BASE_URL}/collection/v1_0/requesttopay`, {
      method: "POST",
      headers: { ...momoHeaders(token, referenceId), "Content-Type": "application/json" },
      body: JSON.stringify({ amount: String(cents), currency, externalId: externalId || referenceId, payer: { partyIdType: "MSISDN", partyId: normaliseMsisdn(payerMsisdn) }, payerMessage, payeeNote })
    });
    if (response.status !== 202) throw new Error(`MoMo request-to-pay failed (${response.status}).`);
    payments.set(referenceId, { referenceId, amount: cents, currency, items, externalId: externalId || referenceId, state: "PENDING" });
    res.status(202).json({ referenceId, status: "PENDING" });
  } catch (error) { next(error); }
});

app.get("/api/payments/momo/:referenceId", async (req, res, next) => {
  try {
    const { referenceId } = req.params;
    const payment = payments.get(referenceId);
    if (!payment) return res.status(404).json({ error: "Payment reference not found." });
    const token = await momoAccessToken();
    const response = await fetch(`${MOMO_BASE_URL}/collection/v1_0/requesttopay/${referenceId}`, { headers: momoHeaders(token) });
    if (!response.ok) throw new Error(`MoMo status request failed (${response.status}).`);
    const providerPayment = await response.json();
    payment.state = providerPayment.status;
    if (providerPayment.status === "SUCCESSFUL" && !orders.has(referenceId)) {
      orders.set(referenceId, { id: `ord_${randomUUID()}`, paymentReference: referenceId, amount: payment.amount, currency: payment.currency, items: payment.items, status: "CONFIRMED", financialTransactionId: providerPayment.financialTransactionId || null });
    }
    res.json({ ...providerPayment, order: orders.get(referenceId) || null });
  } catch (error) { next(error); }
});

app.get("/api/orders/:paymentReference", (req, res) => {
  const order = orders.get(req.params.paymentReference);
  if (!order) return res.status(404).json({ error: "Order not found or payment is not yet successful." });
  res.json({ order });
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(502).json({ error: error.message || "An unexpected server error occurred." });
});

app.listen(PORT, () => console.log(`MoMo Market API running on http://localhost:${PORT}`));
